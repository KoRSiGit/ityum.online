import"../chunks/experience.076580e4.js";import{l}from"../chunks/_page.8059cda0.js";export{l as load};
