import{S as F,i as G,s as J,k as d,q as E,a as v,y as C,l as p,m as h,r as b,h as r,c as u,z as O,n as D,b as j,K as n,A,g as H,d as K,B as T}from"../chunks/index.9c325de6.js";import{B as L}from"../chunks/Button.68b3f28e.js";import{E as M}from"../chunks/error.d3fe8b85.js";function N(y){let t;return{c(){t=E("Start over")},l(o){t=b(o,"Start over")},m(o,f){j(o,t,f)},d(o){o&&r(t)}}}function Q(y){let t,o,f,I,e,w,x,S,m,c,z,_,B,R,W,k,l,g;return c=new M({}),l=new L({props:{href:"/",$$slots:{default:[N]},$$scope:{ctx:y}}}),{c(){t=d("div"),o=d("script"),f=E(`console.log('ends with /', window.location.pathname.endsWith('/'));
		if (window.location.pathname.endsWith('/')) {
			console.log(
				\`Redirecting from \${window.location.pathname} to \${window.location.pathname.slice(0, -1)}\`
			);
			window.location.pathname = window.location.pathname.slice(0, -1);
		}`),I=v(),e=d("div"),w=d("h1"),x=E("Oh no! 404!"),S=v(),m=d("div"),C(c.$$.fragment),z=v(),_=d("p"),B=E("It seems like coffee was spilled all over this page, and now it can't be displayed."),R=v(),W=d("br"),k=v(),C(l.$$.fragment),this.h()},l(a){t=p(a,"DIV",{class:!0});var i=h(t);o=p(i,"SCRIPT",{});var $=h(o);f=b($,`console.log('ends with /', window.location.pathname.endsWith('/'));
		if (window.location.pathname.endsWith('/')) {
			console.log(
				\`Redirecting from \${window.location.pathname} to \${window.location.pathname.slice(0, -1)}\`
			);
			window.location.pathname = window.location.pathname.slice(0, -1);
		}`),$.forEach(r),I=u(i),e=p(i,"DIV",{class:!0});var s=h(e);w=p(s,"H1",{});var P=h(w);x=b(P,"Oh no! 404!"),P.forEach(r),S=u(s),m=p(s,"DIV",{class:!0});var V=h(m);O(c.$$.fragment,V),V.forEach(r),z=u(s),_=p(s,"P",{});var q=h(_);B=b(q,"It seems like coffee was spilled all over this page, and now it can't be displayed."),q.forEach(r),R=u(s),W=p(s,"BR",{}),k=u(s),O(l.$$.fragment,s),s.forEach(r),i.forEach(r),this.h()},h(){D(m,"class","svg-wrapper svelte-1ezp2f5"),D(e,"class","container svelte-1ezp2f5"),D(t,"class","error-page svelte-1ezp2f5")},m(a,i){j(a,t,i),n(t,o),n(o,f),n(t,I),n(t,e),n(e,w),n(w,x),n(e,S),n(e,m),A(c,m,null),n(e,z),n(e,_),n(_,B),n(e,R),n(e,W),n(e,k),A(l,e,null),g=!0},p(a,[i]){const $={};i&1&&($.$$scope={dirty:i,ctx:a}),l.$set($)},i(a){g||(H(c.$$.fragment,a),H(l.$$.fragment,a),g=!0)},o(a){K(c.$$.fragment,a),K(l.$$.fragment,a),g=!1},d(a){a&&r(t),T(c),T(l)}}}class Z extends F{constructor(t){super(),G(this,t,null,Q,J,{})}}export{Z as default};
