import"../chunks/experience.076580e4.js";import{l}from"../chunks/_page.a2127be2.js";export{l as load};
