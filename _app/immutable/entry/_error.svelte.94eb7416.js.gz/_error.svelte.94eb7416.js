import{S as Q,i as U,s as X,y as B,a as w,k as f,q as H,z as I,c as _,l as p,m as u,r as S,h as r,n as j,A as z,b as V,K as e,g as R,d as W,B as D}from"../chunks/index.9c325de6.js";import{H as Y,F as Z}from"../chunks/Footer.1c4382cb.js";import{B as tt}from"../chunks/Button.68b3f28e.js";import{E as et}from"../chunks/error.d3fe8b85.js";function nt(k){let n;return{c(){n=H("В начало!")},l(s){n=S(s,"В начало!")},m(s,l){V(s,n,l)},d(s){s&&r(n)}}}function at(k){let n,s,l,m,g,q,A,a,E,C,F,v,d,P,b,K,M,N,T,c,x,$,y;return n=new Y({props:{showBackground:!0}}),d=new et({}),c=new tt({props:{href:"/",$$slots:{default:[nt]},$$scope:{ctx:k}}}),$=new Z({}),{c(){B(n.$$.fragment),s=w(),l=f("main"),m=f("div"),g=f("script"),q=H(`console.log('ends with /', window.location.pathname.endsWith('/'));
			if (window.location.pathname.endsWith('/')) {
				console.log(
					\`404 - Redirecting from \${window.location.pathname} to \${window.location.pathname.slice(
						0,
						-1
					)}\`
				);
				window.location.pathname = window.location.pathname.slice(0, -1);
			}`),A=w(),a=f("div"),E=f("h1"),C=H("О, нет!"),F=w(),v=f("div"),B(d.$$.fragment),P=w(),b=f("p"),K=H("Похоже, кто-то пролил кофе на страницу и теперь она не отображается..."),M=w(),N=f("br"),T=w(),B(c.$$.fragment),x=w(),B($.$$.fragment),this.h()},l(t){I(n.$$.fragment,t),s=_(t),l=p(t,"MAIN",{});var o=u(l);m=p(o,"DIV",{class:!0});var h=u(m);g=p(h,"SCRIPT",{});var G=u(g);q=S(G,`console.log('ends with /', window.location.pathname.endsWith('/'));
			if (window.location.pathname.endsWith('/')) {
				console.log(
					\`404 - Redirecting from \${window.location.pathname} to \${window.location.pathname.slice(
						0,
						-1
					)}\`
				);
				window.location.pathname = window.location.pathname.slice(0, -1);
			}`),G.forEach(r),A=_(h),a=p(h,"DIV",{class:!0});var i=u(a);E=p(i,"H1",{});var J=u(E);C=S(J,"О, нет!"),J.forEach(r),F=_(i),v=p(i,"DIV",{class:!0});var L=u(v);I(d.$$.fragment,L),L.forEach(r),P=_(i),b=p(i,"P",{});var O=u(b);K=S(O,"Похоже, кто-то пролил кофе на страницу и теперь она не отображается..."),O.forEach(r),M=_(i),N=p(i,"BR",{}),T=_(i),I(c.$$.fragment,i),i.forEach(r),h.forEach(r),o.forEach(r),x=_(t),I($.$$.fragment,t),this.h()},h(){j(v,"class","svg-wrapper svelte-1ezp2f5"),j(a,"class","container svelte-1ezp2f5"),j(m,"class","error-page svelte-1ezp2f5")},m(t,o){z(n,t,o),V(t,s,o),V(t,l,o),e(l,m),e(m,g),e(g,q),e(m,A),e(m,a),e(a,E),e(E,C),e(a,F),e(a,v),z(d,v,null),e(a,P),e(a,b),e(b,K),e(a,M),e(a,N),e(a,T),z(c,a,null),V(t,x,o),z($,t,o),y=!0},p(t,[o]){const h={};o&1&&(h.$$scope={dirty:o,ctx:t}),c.$set(h)},i(t){y||(R(n.$$.fragment,t),R(d.$$.fragment,t),R(c.$$.fragment,t),R($.$$.fragment,t),y=!0)},o(t){W(n.$$.fragment,t),W(d.$$.fragment,t),W(c.$$.fragment,t),W($.$$.fragment,t),y=!1},d(t){D(n,t),t&&r(s),t&&r(l),D(d),D(c),t&&r(x),D($,t)}}}class lt extends Q{constructor(n){super(),U(this,n,null,at,X,{})}}export{lt as default};
