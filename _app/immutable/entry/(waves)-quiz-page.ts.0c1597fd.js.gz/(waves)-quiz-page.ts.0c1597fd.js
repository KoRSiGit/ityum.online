import"../chunks/experience.076580e4.js";import{l}from"../chunks/_page.8c76f454.js";export{l as load};
