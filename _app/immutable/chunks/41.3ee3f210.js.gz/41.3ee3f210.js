import{default as t}from"../entry/(waves)-geocards-page.svelte.0f202002.js";export{t as component};
