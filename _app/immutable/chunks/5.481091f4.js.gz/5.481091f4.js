import{default as t}from"../entry/(waves)-layout.svelte.48d67333.js";export{t as component};
