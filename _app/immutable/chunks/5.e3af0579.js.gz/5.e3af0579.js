import{default as t}from"../entry/(waves)-layout.svelte.2ee1bdd5.js";export{t as component};
