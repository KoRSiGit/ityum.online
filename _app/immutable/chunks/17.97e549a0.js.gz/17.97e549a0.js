import{default as t}from"../entry/(subject-article)-phiz-running-page.md.a785e5e0.js";export{t as component};
