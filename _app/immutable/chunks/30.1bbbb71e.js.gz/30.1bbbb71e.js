import{default as t}from"../entry/(subject-article)-english-past-cont-page.md.d5d80e73.js";export{t as component};
