import{default as t}from"../entry/(waves)-layout.svelte.72458298.js";export{t as component};
