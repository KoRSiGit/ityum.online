import{default as t}from"../entry/(flashcard)-layout.svelte.483158f6.js";export{t as component};
