import{default as t}from"../entry/(subject-article)-russian-formation-page.md.290ab84f.js";export{t as component};
