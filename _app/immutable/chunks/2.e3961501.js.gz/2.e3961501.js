import{default as t}from"../entry/(blog-article)-layout.svelte.9ad26d28.js";export{t as component};
