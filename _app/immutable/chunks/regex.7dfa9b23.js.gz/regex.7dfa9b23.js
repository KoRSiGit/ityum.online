const t=/^((http|https):\/\/)/;export{t as H};
