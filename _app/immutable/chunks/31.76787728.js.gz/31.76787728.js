import{_ as r}from"./_page.8c76f454.js";import{default as t}from"../entry/(waves)-quiz-page.svelte.4d6f7eb2.js";export{t as component,r as universal};
