import{default as t}from"../entry/(flashcard)-apply-page.md.bff9cb53.js";export{t as component};
