import{default as t}from"../entry/(waves)-blog-page.svelte.e2f280f3.js";export{t as component};
