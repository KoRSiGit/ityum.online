import{default as t}from"../entry/(blog-article)-snowflakes-page.md.158c6900.js";export{t as component};
