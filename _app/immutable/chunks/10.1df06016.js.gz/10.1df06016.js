import{default as t}from"../entry/(blog-article)-snowflakes-page.md.3d8bc260.js";export{t as component};
