import{default as t}from"../entry/_error.svelte.94eb7416.js";export{t as component};
