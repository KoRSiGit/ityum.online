import{default as t}from"../entry/(blog-article)-layout.svelte.d8d17469.js";export{t as component};
