import{default as t}from"../entry/(waves)-slide-ru-page.svelte.dc85ac79.js";export{t as component};
