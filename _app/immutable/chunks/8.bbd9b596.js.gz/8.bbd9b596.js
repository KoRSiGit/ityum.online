import{default as t}from"../entry/(blog-article)-review-page.md.a54414ca.js";export{t as component};
