import{default as t}from"../entry/(blog-article)-swift-page.md.b670c479.js";export{t as component};
