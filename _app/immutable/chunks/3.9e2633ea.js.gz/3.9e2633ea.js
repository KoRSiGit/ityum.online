import{default as t}from"../entry/(flashcard)-layout.svelte.5a6d23ee.js";export{t as component};
