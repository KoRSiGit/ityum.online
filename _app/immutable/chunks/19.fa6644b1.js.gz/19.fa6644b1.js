import{default as t}from"../entry/(subject-article)-culturology-page.md.6949fb21.js";export{t as component};
