import{default as t}from"../entry/(waves)-layout.svelte.caf54af1.js";export{t as component};
