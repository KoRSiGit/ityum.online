import{default as t}from"../entry/(subject-article)-math-fraction-page.md.070c422c.js";export{t as component};
