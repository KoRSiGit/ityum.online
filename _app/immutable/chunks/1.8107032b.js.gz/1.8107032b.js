import{default as t}from"../entry/_error.svelte.ffe1b1e6.js";export{t as component};
