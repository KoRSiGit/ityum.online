import{default as t}from"../entry/(blog-article)-snowflakes-page.md.1c63c66a.js";export{t as component};
