import{default as t}from"../entry/(blog-article)-swift-page.md.72692c01.js";export{t as component};
