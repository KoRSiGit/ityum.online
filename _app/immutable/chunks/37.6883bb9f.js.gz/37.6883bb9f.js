import{default as t}from"../entry/(waves)-404-page.svelte.425080ec.js";export{t as component};
