import{_ as r}from"./_page.a2127be2.js";import{default as t}from"../entry/(waves)-quiz-page.svelte.0a92601b.js";export{t as component,r as universal};
