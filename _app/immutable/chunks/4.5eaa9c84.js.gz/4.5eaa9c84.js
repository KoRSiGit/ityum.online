import{default as t}from"../entry/(subject-article)-layout.svelte.a1aee58c.js";export{t as component};
