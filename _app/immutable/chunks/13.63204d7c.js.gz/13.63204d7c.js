import{default as t}from"../entry/(subject-article)-english-past-cont-page.md.c89f247f.js";export{t as component};
