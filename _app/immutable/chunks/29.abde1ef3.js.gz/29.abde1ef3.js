import{default as t}from"../entry/(waves)-flashcards-page.svelte.83ffc94a.js";export{t as component};
