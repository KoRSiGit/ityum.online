import{default as t}from"../entry/(subject-article)-phiz-running-page.md.32e7d821.js";export{t as component};
