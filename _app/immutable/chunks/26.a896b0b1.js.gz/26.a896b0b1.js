import{default as t}from"../entry/(waves)-slide-page.svelte.fbb5df12.js";export{t as component};
