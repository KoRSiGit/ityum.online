import{default as t}from"../entry/(subject-article)-math-fraction-page.md.ee4f6cc6.js";export{t as component};
