import{default as t}from"../entry/(subject-article)-russian-formation-page.md.07d8ce17.js";export{t as component};
