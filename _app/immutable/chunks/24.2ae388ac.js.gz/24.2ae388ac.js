import{default as t}from"../entry/(geocard)-nikitin-page.md.5740fb67.js";export{t as component};
