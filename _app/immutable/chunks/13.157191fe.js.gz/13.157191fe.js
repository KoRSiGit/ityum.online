import{default as t}from"../entry/(flashcard)-doubt-page.md.86c1d375.js";export{t as component};
