import{default as t}from"../entry/(flashcard)-layout.svelte.d1e6343a.js";export{t as component};
