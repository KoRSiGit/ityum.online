import{default as t}from"../entry/(subject-article)-biology-virus-page.md.520bf751.js";export{t as component};
