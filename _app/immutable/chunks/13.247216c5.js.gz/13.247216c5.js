import{default as t}from"../entry/(flashcard)-doubt-page.md.cddcdf62.js";export{t as component};
