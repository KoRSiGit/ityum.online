import{default as t}from"../entry/(blog-article)-review-page.md.ab849705.js";export{t as component};
