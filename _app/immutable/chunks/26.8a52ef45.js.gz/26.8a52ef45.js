import{default as t}from"../entry/(waves)-page.svelte.50106d44.js";export{t as component};
