import{default as t}from"../entry/(flashcard)-apply-page.md.7a52d170.js";export{t as component};
