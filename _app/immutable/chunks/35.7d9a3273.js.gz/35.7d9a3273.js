import{default as t}from"../entry/(waves)-slide-eng-page.svelte.4bfc0969.js";export{t as component};
