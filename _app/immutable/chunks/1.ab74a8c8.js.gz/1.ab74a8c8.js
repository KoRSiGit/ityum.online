import{default as t}from"../entry/_error.svelte.f0b17144.js";export{t as component};
