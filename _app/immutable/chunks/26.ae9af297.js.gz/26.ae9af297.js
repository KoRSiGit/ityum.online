import{default as t}from"../entry/(waves)-page.svelte.8fd926cf.js";export{t as component};
