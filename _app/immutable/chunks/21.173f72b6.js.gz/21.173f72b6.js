import{default as t}from"../entry/(subject-article)-izo-mezen-page.md.89d91335.js";export{t as component};
