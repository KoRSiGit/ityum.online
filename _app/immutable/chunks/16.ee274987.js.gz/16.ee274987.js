import{default as t}from"../entry/(flashcard)-mandatory-page.md.3a24cae2.js";export{t as component};
