import{default as t}from"../entry/(blog-article)-snowflakes-page.md.a932618c.js";export{t as component};
