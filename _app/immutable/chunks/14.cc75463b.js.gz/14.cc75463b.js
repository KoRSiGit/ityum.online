import{default as t}from"../entry/(flashcard)-flexible-page.md.b05cc53d.js";export{t as component};
