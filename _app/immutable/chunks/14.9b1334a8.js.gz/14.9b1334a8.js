import{default as t}from"../entry/(flashcard)-flexible-page.md.ad231899.js";export{t as component};
