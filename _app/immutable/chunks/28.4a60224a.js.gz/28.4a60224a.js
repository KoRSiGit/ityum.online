import{default as t}from"../entry/(subject-article)-countries-eng-rus-schools-1-page.md.e6e7ac5c.js";export{t as component};
