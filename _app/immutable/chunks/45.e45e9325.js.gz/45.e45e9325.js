import{default as t}from"../entry/(waves)-slide-page.svelte.06d5d0f1.js";export{t as component};
