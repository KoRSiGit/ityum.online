import{default as t}from"../entry/(blog-article)-kamenka-page.md.12a26334.js";export{t as component};
