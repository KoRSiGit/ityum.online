import{default as t}from"../entry/(subject-article)-math-fraction-page.md.757b27ad.js";export{t as component};
