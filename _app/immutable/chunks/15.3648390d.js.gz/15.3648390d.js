import{default as t}from"../entry/(flashcard)-flexible-page.md.48d82ea4.js";export{t as component};
