import{default as t}from"../entry/(geocard)-dejnev-page.md.146fc82a.js";export{t as component};
