import{default as t}from"../entry/(subject-article)-izo-mezen-page.md.b5c3702e.js";export{t as component};
