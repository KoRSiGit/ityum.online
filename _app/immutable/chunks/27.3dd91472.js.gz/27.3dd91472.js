import{default as t}from"../entry/(waves)-slide-eng-page.svelte.b5b2713f.js";export{t as component};
