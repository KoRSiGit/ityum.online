import{default as t}from"../entry/(subject-article)-layout.svelte.e3cc80bc.js";export{t as component};
