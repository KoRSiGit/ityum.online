import{S as Q,i as R,s as T,L as s,q as U,M as a,m as c,r as V,h as l,n as t,b as W,K as e,C as F}from"./index.9c325de6.js";function X(O){let h,u,B,D,d,p,m,x,y,n,E,i,o,g,v,_,M,w,Z,k,S,P,f,L,b,q,A;return{c(){h=s("svg"),u=s("defs"),B=s("style"),D=U(`.cls-1,
			.cls-7 {
				fill: #c7dcf9;
			}
			.cls-14,
			.cls-2 {
				fill: #fea691;
			}
			.cls-3 {
				isolation: isolate;
			}
			.cls-4,
			.cls-9 {
				fill: #e1ecff;
			}
			.cls-5 {
				fill: #f0f4ff;
			}
			.cls-6 {
				clip-path: url(#clip-path);
			}
			.cls-7 {
				opacity: 0.37;
			}
			.cls-14,
			.cls-7,
			.cls-9 {
				mix-blend-mode: multiply;
			}
			.cls-8 {
				fill: #99adf9;
			}
			.cls-9 {
				opacity: 0.58;
			}
			.cls-10 {
				fill: none;
				stroke: #1c3177;
				stroke-linecap: round;
				stroke-miterlimit: 10;
				stroke-width: 9px;
			}
			.cls-11 {
				fill: #1c3177;
			}
			.cls-12 {
				fill: #ff97c9;
			}
			.cls-13 {
				clip-path: url(#clip-path-2);
			}
			.cls-14 {
				opacity: 0.21;
			}
		`),d=s("clipPath"),p=s("ellipse"),m=s("clipPath"),x=s("path"),y=s("g"),n=s("g"),E=s("path"),i=s("ellipse"),o=s("ellipse"),g=s("g"),v=s("path"),_=s("path"),M=s("path"),w=s("path"),Z=s("path"),k=s("path"),S=s("path"),P=s("path"),f=s("g"),L=s("path"),b=s("path"),q=s("path"),A=s("path"),this.h()},l(C){h=a(C,"svg",{xmlns:!0,"xmlns:xlink":!0,viewBox:!0});var K=c(h);u=a(K,"defs",{});var j=c(u);B=a(j,"style",{});var G=c(B);D=V(G,`.cls-1,
			.cls-7 {
				fill: #c7dcf9;
			}
			.cls-14,
			.cls-2 {
				fill: #fea691;
			}
			.cls-3 {
				isolation: isolate;
			}
			.cls-4,
			.cls-9 {
				fill: #e1ecff;
			}
			.cls-5 {
				fill: #f0f4ff;
			}
			.cls-6 {
				clip-path: url(#clip-path);
			}
			.cls-7 {
				opacity: 0.37;
			}
			.cls-14,
			.cls-7,
			.cls-9 {
				mix-blend-mode: multiply;
			}
			.cls-8 {
				fill: #99adf9;
			}
			.cls-9 {
				opacity: 0.58;
			}
			.cls-10 {
				fill: none;
				stroke: #1c3177;
				stroke-linecap: round;
				stroke-miterlimit: 10;
				stroke-width: 9px;
			}
			.cls-11 {
				fill: #1c3177;
			}
			.cls-12 {
				fill: #ff97c9;
			}
			.cls-13 {
				clip-path: url(#clip-path-2);
			}
			.cls-14 {
				opacity: 0.21;
			}
		`),G.forEach(l),d=a(j,"clipPath",{id:!0});var H=c(d);p=a(H,"ellipse",{class:!0,cx:!0,cy:!0,rx:!0,ry:!0,transform:!0}),c(p).forEach(l),H.forEach(l),m=a(j,"clipPath",{id:!0});var I=c(m);x=a(I,"path",{class:!0,d:!0}),c(x).forEach(l),I.forEach(l),j.forEach(l),y=a(K,"g",{class:!0});var J=c(y);n=a(J,"g",{id:!0,"data-name":!0});var r=c(n);E=a(r,"path",{class:!0,d:!0}),c(E).forEach(l),i=a(r,"ellipse",{class:!0,cx:!0,cy:!0,rx:!0,ry:!0,transform:!0}),c(i).forEach(l),o=a(r,"ellipse",{class:!0,cx:!0,cy:!0,rx:!0,ry:!0,transform:!0}),c(o).forEach(l),g=a(r,"g",{class:!0});var N=c(g);v=a(N,"path",{class:!0,d:!0}),c(v).forEach(l),N.forEach(l),_=a(r,"path",{class:!0,d:!0}),c(_).forEach(l),M=a(r,"path",{class:!0,d:!0}),c(M).forEach(l),w=a(r,"path",{class:!0,d:!0}),c(w).forEach(l),Z=a(r,"path",{class:!0,d:!0}),c(Z).forEach(l),k=a(r,"path",{class:!0,d:!0}),c(k).forEach(l),S=a(r,"path",{class:!0,d:!0}),c(S).forEach(l),P=a(r,"path",{class:!0,d:!0}),c(P).forEach(l),f=a(r,"g",{class:!0});var z=c(f);L=a(z,"path",{class:!0,d:!0}),c(L).forEach(l),b=a(z,"path",{class:!0,d:!0}),c(b).forEach(l),q=a(z,"path",{class:!0,d:!0}),c(q).forEach(l),z.forEach(l),A=a(r,"path",{class:!0,d:!0}),c(A).forEach(l),r.forEach(l),J.forEach(l),K.forEach(l),this.h()},h(){t(p,"class","cls-1"),t(p,"cx","447.2"),t(p,"cy","511.48"),t(p,"rx","107.95"),t(p,"ry","147.31"),t(p,"transform","translate(-46.98 45.23) rotate(-5.5)"),t(d,"id","clip-path"),t(x,"class","cls-2"),t(x,"d","M542.23,589.77s-181.59-2.75-222.59,7-33.82,36.64-21.52,48.68,12.55,30-16.91,32.29-109.67,8.45-119.92,36.89,31,52.53,115,49.71,183.2-17.23,204.21.23-30.49,20-7.94,42.56,140.93,13.84,180.9-2.3,61-43.05,37.92-70.21S637.48,701,645.31,685.93c6.66-12.82,6.37-31.69-10.27-40.06-27.14,4.7-168.53,31.83-168.53,31.83S461,661.84,477.1,655,524,637.36,542.23,589.77Z"),t(m,"id","clip-path-2"),t(E,"class","cls-4"),t(E,"d","M447.49,344.26l364.5,31a33.12,33.12,0,0,1,23.78,13c11,14.48,27.71,42.06,34.84,82.07,5.79,32.52-5.7,92.52-26.73,125.65a33,33,0,0,1-21.74,14.6L466.2,677.73Z"),t(i,"class","cls-5"),t(i,"cx","450.47"),t(i,"cy","511.16"),t(i,"rx","126.33"),t(i,"ry","167.3"),t(i,"transform","translate(-46.93 45.54) rotate(-5.5)"),t(o,"class","cls-1"),t(o,"cx","447.2"),t(o,"cy","511.48"),t(o,"rx","107.95"),t(o,"ry","147.31"),t(o,"transform","translate(-46.98 45.23) rotate(-5.5)"),t(v,"class","cls-7"),t(v,"d","M475.26,354s-66.1,119.73-18.13,235.37c-32.09,54-23.37,113.32-17.23,115.68s215.69-73.48,221.49-69.38S609,320,609,320Z"),t(g,"class","cls-6"),t(_,"class","cls-8"),t(_,"d","M562.53,354s55.11,46.7,64.59,152.53c8,88.86-52.27,150.66-52.27,150.66l201.59-38s43.71-57,43.71-129c0-79.43-52.84-118.73-52.84-118.73Z"),t(M,"class","cls-9"),t(M,"d","M552.59,556c-4,15.57-10.36,33.8-10.36,33.8l-78.54,43.08,2.51,44.88,355.94-67.16A33,33,0,0,0,843.88,596c8.67-13.67,15.72-31.91,20.6-50.9Z"),t(w,"class","cls-10"),t(w,"d","M661.39,413.94s30.11-3.84,34.85,19c3.46,16.69-18.93,23.93-18.93,23.93"),t(Z,"class","cls-10"),t(Z,"d","M685.67,526.45s31.71,8.26,25.64,31.55c-3.77,14.46-29.25,17.28-29.25,17.28"),t(k,"class","cls-11"),t(k,"d","M740.29,456.89c-8.93-.47-13.45,11.15-13.32,23.58s2.56,32,14.35,32.58,14-13.32,13.07-28.08S750,457.4,740.29,456.89Z"),t(S,"class","cls-12"),t(S,"d","M752.11,469.77s-10.45,3.61-10.28,12.57,5.07,16.14,12,17.64A52.89,52.89,0,0,0,752.11,469.77Z"),t(P,"class","cls-2"),t(P,"d","M542.23,589.77s-181.59-2.75-222.59,7-33.82,36.64-21.52,48.68,12.55,30-16.91,32.29-109.67,8.45-119.92,36.89,31,52.53,115,49.71,183.2-17.23,204.21.23-30.49,20-7.94,42.56,140.93,13.84,180.9-2.3,61-43.05,37.92-70.21S637.48,701,645.31,685.93c6.66-12.82,6.37-31.69-10.27-40.06-27.14,4.7-168.53,31.83-168.53,31.83S461,661.84,477.1,655,524,637.36,542.23,589.77Z"),t(L,"class","cls-14"),t(L,"d","M413.24,590.15S514.46,604.72,477.1,655c72,20.88,138.75-77.68,138.75-77.68L498.67,553.37Z"),t(b,"class","cls-14"),t(b,"d","M531.39,665.3s105.6-12.94,117,12.43c26.24-13.33,20.09-46.12,20.09-46.12L567,641.86Z"),t(q,"class","cls-14"),t(q,"d","M213.2,686.56c-19.79,8.08-30.89,41.22,11.13,49.25s218.31-10.08,246.15,5.12,14.8,33.86,14.8,33.86l-338.5,23.88L139.61,697.2Z"),t(f,"class","cls-13"),t(A,"class","cls-2"),t(A,"d","M278.65,862.72c-7.39-12.71,22.89-28.35,54-28.86s55.86,14,53.64,23.91S349.19,872,330.57,872.12,282.92,870.07,278.65,862.72Z"),t(n,"id","Layer_3"),t(n,"data-name","Layer 3"),t(y,"class","cls-3"),t(h,"xmlns","http://www.w3.org/2000/svg"),t(h,"xmlns:xlink","http://www.w3.org/1999/xlink"),t(h,"viewBox","0 0 1080 1080")},m(C,K){W(C,h,K),e(h,u),e(u,B),e(B,D),e(u,d),e(d,p),e(u,m),e(m,x),e(h,y),e(y,n),e(n,E),e(n,i),e(n,o),e(n,g),e(g,v),e(n,_),e(n,M),e(n,w),e(n,Z),e(n,k),e(n,S),e(n,P),e(n,f),e(f,L),e(f,b),e(f,q),e(n,A)},p:F,i:F,o:F,d(C){C&&l(h)}}}class $ extends Q{constructor(h){super(),R(this,h,null,X,T,{})}}export{$ as E};
