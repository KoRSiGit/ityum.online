import{default as t}from"../entry/(blog-article)-march8-page.md.154fd4d8.js";export{t as component};
