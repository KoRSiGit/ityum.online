import{default as t}from"../entry/(blog-article)-layout.svelte.a1aee58c.js";export{t as component};
