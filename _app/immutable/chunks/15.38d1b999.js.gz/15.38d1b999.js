import{default as t}from"../entry/(flashcard)-institution-page.md.0fc4c9d6.js";export{t as component};
