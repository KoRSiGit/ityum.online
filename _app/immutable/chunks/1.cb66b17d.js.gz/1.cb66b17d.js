import{default as t}from"../entry/_error.svelte.b5ce0313.js";export{t as component};
