import{default as t}from"../entry/(blog-article)-tardigrades-page.md.2cc6e04e.js";export{t as component};
