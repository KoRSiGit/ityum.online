import{default as t}from"../entry/(subject-article)-culturology-page.md.794f7a20.js";export{t as component};
