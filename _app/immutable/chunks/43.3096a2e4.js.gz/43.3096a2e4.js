import{_ as r}from"./_page.8c76f454.js";import{default as t}from"../entry/(waves)-quiz-schools-page.svelte.18e8852a.js";export{t as component,r as universal};
