import{_ as r}from"./_page.f1a8916d.js";import{default as t}from"../entry/(waves)-game-page.svelte.7004dfdf.js";export{t as component,r as universal};
