import{default as t}from"../entry/(subject-article)-layout.svelte.9ad26d28.js";export{t as component};
