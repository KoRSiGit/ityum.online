import{default as t}from"../entry/(waves)-page.svelte.7c8233e7.js";export{t as component};
