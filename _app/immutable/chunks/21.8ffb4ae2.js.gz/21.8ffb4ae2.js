import{default as t}from"../entry/(waves)-blog-page.svelte.cd549de9.js";export{t as component};
