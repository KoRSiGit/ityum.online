import{default as t}from"../entry/(waves)-page.svelte.ce47a866.js";export{t as component};
