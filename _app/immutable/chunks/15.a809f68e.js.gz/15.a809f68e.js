import{default as t}from"../entry/(subject-article)-literature-review-page.md.bd749e14.js";export{t as component};
