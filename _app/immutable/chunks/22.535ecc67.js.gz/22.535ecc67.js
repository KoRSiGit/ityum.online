import{default as t}from"../entry/(subject-article)-literature-review-page.md.7b6b2baf.js";export{t as component};
