import{default as t}from"../entry/(flashcard)-apply-page.md.89eed770.js";export{t as component};
