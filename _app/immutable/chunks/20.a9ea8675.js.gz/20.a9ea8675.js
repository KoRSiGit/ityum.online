import{default as t}from"../entry/(subject-article)-english-past-cont-page.md.67146915.js";export{t as component};
