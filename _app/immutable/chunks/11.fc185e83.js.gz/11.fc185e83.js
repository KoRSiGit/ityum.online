import{default as t}from"../entry/(subject-article)-countries-eng-rus-schools-1-page.md.ad6bbe09.js";export{t as component};
