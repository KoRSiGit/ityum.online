import{default as t}from"../entry/(waves)-404-page.svelte.2903d713.js";export{t as component};
