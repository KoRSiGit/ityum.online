import{_ as r}from"./_layout.da46b06b.js";import{default as t}from"../entry/_layout.svelte.b2609744.js";export{t as component,r as universal};
