import{default as t}from"../entry/(blog-article)-kamenka-page.md.52b5c5be.js";export{t as component};
