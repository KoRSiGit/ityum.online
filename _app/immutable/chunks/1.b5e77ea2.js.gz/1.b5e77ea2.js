import{default as t}from"../entry/_error.svelte.5692453a.js";export{t as component};
