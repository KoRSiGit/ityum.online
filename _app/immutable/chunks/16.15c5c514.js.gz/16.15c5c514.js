import{default as t}from"../entry/(flashcard)-institution-page.md.3cc20856.js";export{t as component};
