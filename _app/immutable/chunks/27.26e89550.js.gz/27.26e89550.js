import{default as t}from"../entry/(waves)-404-page.svelte.7621c741.js";export{t as component};
