import{default as t}from"../entry/(subject-article)-izo-mezen-page.md.5bfa9617.js";export{t as component};
