import{default as t}from"../entry/(waves)-flashcards-page.svelte.42ff4019.js";export{t as component};
