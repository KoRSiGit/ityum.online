import{default as t}from"../entry/(waves)-blog-page.svelte.8b5eec55.js";export{t as component};
