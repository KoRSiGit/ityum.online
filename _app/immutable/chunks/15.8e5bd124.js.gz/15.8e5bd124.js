import{default as t}from"../entry/(flashcard)-institution-page.md.53189971.js";export{t as component};
