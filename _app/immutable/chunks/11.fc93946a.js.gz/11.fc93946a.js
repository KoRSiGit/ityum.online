import{default as t}from"../entry/(blog-article)-tardigrades-page.md.d6f3ff82.js";export{t as component};
