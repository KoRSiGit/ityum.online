import{default as t}from"../entry/(subject-article)-phiz-running-page.md.cc78c80e.js";export{t as component};
